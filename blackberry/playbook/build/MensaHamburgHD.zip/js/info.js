/* 
 * Mehr oder minder statische Konfigurationsdatei für einige Texte
 * 
 */
(function(){
	info = {
		appName  : "Mensa-Hamburg App",
		appDesc  : "Dies ist eine App von Studenten für Studenten und sie ist Open Source!\n Dein Feedback ist immer Willkommen!",
		appURL   : "http://johannjacobsohn.github.com/Mensa-Hamburg-App/",
		appEmail : "mensa-hamburg-app@directbox.com",

		notConfTitle : "Noch nicht konfiguriert",
		notConfText : "Uh, scheinbar ist hier noch nichts konfiguriert, daher werden *keine* Mensen geladen... Du musst welche aktivieren um etwas zu sehen."
	}
})();
