// js/info.js

(function() {
info = {
appName: "Mensa-Hamburg App",
appDesc: "Dies ist eine App von Studenten f\u00fcr Studenten und sie ist Open Source!\n Dein Feedback ist immer Willkommen!",
appURL: "http://johannjacobsohn.github.com/Mensa-Hamburg-App/",
appEmail: "mensa-hamburg-app@directbox.com",
notConfTitle: "Noch nicht konfiguriert",
notConfText: "Uh, scheinbar ist hier noch nichts konfiguriert, daher werden *keine* Mensen geladen... Du musst welche aktivieren um etwas zu sehen."
};
})();

// js/utils.js

function isEmpty(a) {
for (var b in a) if (a.hasOwnProperty(b)) return !1;
return !0;
}

function deepCopy(a) {
var b = a, c;
if (a && typeof a == "object") {
b = Object.prototype.toString.call(a) === "[object Array]" ? [] : {};
for (c in a) b[c] = deepCopy(a[c]);
}
return b;
}

function dateToString(a, b) {
var c = a.split("-");
return formatDate(new Date(c[0], c[1] - 1, c[2]), b);
}

function formatDate(a, b) {
var b = b || "de", c = 864e5, d = daysBetween(new Date, a), e = {
de: {
"-1": "Gestern",
"0": "Heute",
"1": "Morgen"
},
en: {
"-1": "Yesterday",
"0": "Today",
"1": "Tomorrow"
}
}, f = {
de: [ "Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Sonnabend" ],
en: [ "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" ]
}, g = {
de: f[b][a.getDay()] + ", " + a.getDate() + "." + (a.getMonth() + 1) + ".",
en: f[b][a.getDay()] + ", " + a.getDate() + "." + (a.getMonth() + 1) + "."
};
return d >= -1 && d <= 1 ? e[b][d] : g[b];
}

function daysBetween(a, b) {
var c = new Date(a.getFullYear(), a.getMonth(), a.getDate()), d = new Date(b.getFullYear(), b.getMonth(), b.getDate()), e = 864e5, f = d.getTime() - c.getTime(), g = f / e;
return Math.floor(g);
}

Date.prototype.getWeek = function() {
var a = new Date;
a.setFullYear(this.getFullYear(), this.getMonth(), this.getDate());
var b = a.getDay();
b == 0 && (b = 7), a.setDate(a.getDate() + (4 - b));
var c = a.getFullYear(), d = Math.floor((a.getTime() - new Date(c, 0, 1, -6)) / 864e5), e = 1 + Math.floor(d / 7);
return e;
}, Array.prototype.indexOf || (Array.prototype.indexOf = function(a, b) {
for (var c = b || 0, d = this.length; c < d; c++) if (this[c] === a) return c;
return -1;
}), String.prototype.trim || (String.prototype.trim = function() {
return this.replace(/^\s\s*/, "").replace(/\s\s*$/, "");
}), Array.prototype.forEach || (Array.prototype.forEach = function(a, b) {
var c, d;
if (this == null) throw new TypeError("this is null or not defined");
var e = Object(this), f = e.length >>> 0;
if ({}.toString.call(a) != "[object Function]") throw new TypeError(a + " is not a function");
b && (c = b), d = 0;
while (d < f) {
var g;
d in e && (g = e[d], a.call(c, g, d, e)), d++;
}
}), Array.prototype.map || (Array.prototype.map = function(a, b) {
var c, d, e;
if (this == null) throw new TypeError(" this is null or not defined");
var f = Object(this), g = f.length >>> 0;
if ({}.toString.call(a) != "[object Function]") throw new TypeError(a + " is not a function");
b && (c = b), d = Array(g), e = 0;
while (e < g) {
var h, i;
e in f && (h = f[e], i = a.call(c, h, e, f), d[e] = i), e++;
}
return d;
});

// js/data.js

var data = function() {
var a = "3", b = {}, c = function(a) {
return typeof b[a] != "undefined" ? b[a] : localStorage.getItem(a);
}, d = function(a, c) {
return b[a] = c, localStorage.setItem(a, c);
}, e = function(a) {
return delete b[a], localStorage.removeItem(a);
}, f = function() {
return b = {}, localStorage.clear();
};
return c("version") !== a && (f(), d("version", a)), {
save: d,
set: d,
get: c,
remove: e,
clear: f
};
}();

// js/conf.js

(function() {
conf = {
getSavedURLs: function() {
try {
return JSON.parse(data.get("urls")) || [];
} catch (a) {
return [];
}
},
getURLs: function() {
var a = [], b = "";
for (b in urls.mensenWeek) a.push(b);
return a;
},
setURLs: function(a) {
return data.save("urls", JSON.stringify(a));
},
isConfigured: function(a) {
try {
return typeof localStorage.getItem("urls") == "string";
} catch (b) {
return !1;
}
},
getMensaInfo: function() {
var a = [], b = this.getURLs(), c = this.getSavedURLs(), d = 0;
for (d = 0; d < b.length; d++) a.push({
name: b[d],
active: c.indexOf(b[d]) != -1
});
return a;
},
setStudentPrices: function(a) {
return data.save("displayStudentPrices", a ? "1" : "0");
},
displayStudentPrices: function() {
return typeof data.get("displayStudentPrices") == "undefined" || data.get("displayStudentPrices") === null || data.get("displayStudentPrices") === "1";
}
};
})();

// js/urls.js

(function() {
urls = {
mensenWeek: {
Alexanderstrasse: "http://speiseplan.studierendenwerk-hamburg.de/index.php/de/660/2012/{{week}}/",
Armgartstrasse: "http://speiseplan.studierendenwerk-hamburg.de/index.php/de/590/2012/{{week}}/",
Averhoffstrasse: "http://speiseplan.studierendenwerk-hamburg.de/index.php/de/650/2012/{{week}}/",
Bergedorf: "http://speiseplan.studierendenwerk-hamburg.de/index.php/de/520/2012/{{week}}/",
"Berliner Tor": "http://speiseplan.studierendenwerk-hamburg.de/index.php/de/530/2012/{{week}}/",
"Botanischer Garten": "http://speiseplan.studierendenwerk-hamburg.de/index.php/de/560/2012/{{week}}/",
"Bucerius Law School": "http://speiseplan.studierendenwerk-hamburg.de/index.php/de/410/2012/{{week}}/",
Campus: "http://speiseplan.studierendenwerk-hamburg.de/index.php/de/340/2012/{{week}}/",
"City Nord": "http://speiseplan.studierendenwerk-hamburg.de/index.php/de/550/2012/{{week}}/",
Finkenau: "http://speiseplan.studierendenwerk-hamburg.de/index.php/de/620/2012/{{week}}/",
Geomatikum: "http://speiseplan.studierendenwerk-hamburg.de/index.php/de/540/2012/{{week}}/",
Harburg: "http://speiseplan.studierendenwerk-hamburg.de/index.php/de/570/2012/{{week}}/",
Jungiusstrasse: "http://speiseplan.studierendenwerk-hamburg.de/index.php/de/610/2012/{{week}}/",
Philosophenturm: "http://speiseplan.studierendenwerk-hamburg.de/index.php/de/350/2012/{{week}}/",
Stellingen: "http://speiseplan.studierendenwerk-hamburg.de/index.php/de/580/2012/{{week}}/",
Studierendenhaus: "http://speiseplan.studierendenwerk-hamburg.de/index.php/de/310/2012/{{week}}/"
},
mock: {
Alexanderstrasse: "mock/alexanderstrasse.html",
Armgartstrasse: "mock/armgardtstrasse.html",
Averhoffstrasse: "mock/averhoffstrasse.html",
Bergedorf: "mock/bergedorf.html",
"Berliner Tor": "mock/berlinertor.html",
"Botanischer Garten": "mock/botanischergarten.html",
"Bucerius Law School": "mock/buzze.html",
Campus: "mock/campus.html",
"City Nord": "mock/citynord.html",
Finkenau: "mock/finkenau.html",
Geomatikum: "mock/geomatikum.html",
Harburg: "mock/harburg.html",
Jungiusstrasse: "mock/jungiusstrasse.html",
Philosophenturm: "mock/philosophenturm.html",
Stellingen: "mock/stellingen.html",
Studierendenhaus: "mock/studierendenhaus.html"
}
};
})();

// js/xhr.js

(function() {
xhr = {
get: function(a, b, c, d) {
var e = new XMLHttpRequest;
e.open("GET", a, !0), e.onreadystatechange = function() {
e.readyState === 4 && (e.status === 200 ? b(e.responseText, d) : e.status === 0 ? b(e.responseText, d) : typeof c == "function" && c(e.responseText, d));
}, e.send(null);
},
getJSON: function(a, b, c) {
this.get(a, function(a) {
b(JSON.parse(a));
}, c);
},
putJSON: function(a, b, c, d) {
var e = new XMLHttpRequest;
e.open("PUT", a, !0), e.onreadystatechange = function() {
e.readyState === 4 && (e.status === 200 ? c(e.responseText) : typeof d == "function" && d(e.responseText));
}, e.setRequestHeader("Content-Type", "application/json"), e.send(JSON.stringify(b));
}
};
})();

// js/storage.js

var storage = function() {
var a = [], b = [], c = !1, e = typeof debug != "undefined" && debug ? new Date(2012, 0, 24) : new Date, f = function() {
return e.getWeek();
}, g = [], h = {}, i = [], j = data.get("persistentFilters") || "1", k = function(a) {
j = a ? "1" : "0", data.set("persistentFilters", j);
}, l = function() {
return j === "1";
}, m = {}, n = {}, o = function() {
j && (m = JSON.parse(data.get("filterProperties") || "{}"), n = JSON.parse(data.get("filterValues") || "{}"));
}, q = function() {
j && (data.set("filterProperties", JSON.stringify(m)), data.set("filterValues", JSON.stringify(n)));
}, r = function(d) {
x(function() {
var e = 0, f;
if (!c) {
b = [];
for (e = 0; e < a.length; e++) b.push(a[e]);
var g = function(a) {
return n[f].indexOf(a[f]) !== -1;
};
for (f in m) m.hasOwnProperty(f) && (b = b.filter(g));
c = !0;
}
d(b);
});
}, s = function(a, b) {
c = !1, typeof b == "string" && (b = [ b ]), a === "date" && (e = Q(b.sort()[b.length - 1])), m[a] = a, n[a] = b, q();
}, t = function(a) {
c = !1, delete m[a], delete n[a], q();
}, u = function() {
c = !1, filterLength = {}, filters = {}, q();
}, v = function(a) {
r(function(b) {
var c = b.sort(function(a, b) {
var c = 0, d = 0, e = a.mensa.toLowerCase(), f = b.mensa.toLowerCase(), g = a.date.split("-"), h = b.date.split("-");
return e < f ? c = -10 : e > f && (c = 10), d = parseInt(g[0], 10) * 100 + parseInt(g[1], 10) * 10 + parseInt(g[2], 10) - parseInt(h[0], 10) * 100 - parseInt(h[1], 10) * 10 - parseInt(h[2], 10), c + d * 100;
}), d = typeof n.mensa != "undefined", e = d && n.mensa.length || 0, f = typeof n.date != "undefined" && n.date.length === 1, g = [], h = "", i = "", j = 0, k = c.length, l = !1, m = conf.getSavedURLs().length > 1 || !0;
d && e === 1 && b[0] && g.push({
header: b[0].mensa,
type: "header",
headerType: "mensa"
});
for (j = 0; j < k; j++) l = j === 0, i != c[j].date && !f && (g.length > 0 && (g[g.length - 1].last = !0), l = !0, g.push({
header: c[j].date,
type: "header",
headerType: "date"
})), h != c[j].mensa && (!d || e !== 1) && m && (g.length > 0 && (g[g.length - 1].last = !0), l = !0, g.push({
header: c[j].mensa,
type: "header",
headerType: "mensa"
})), c[j].type = "item", c[j].first = l, c[j].last = !1, g.push(c[j]), h = c[j].mensa, i = c[j].date;
g.length > 0 && (g[g.length - 1].last = !0), a(g);
});
}, w = function() {
var c = conf.getSavedURLs(), d = "", e = "", f = 0, g = 0;
B(), a = a.filter(function(a) {
return c.indexOf(a.mensa) !== -1;
}), b = b.filter(function(a) {
return c.indexOf(a.mensa) !== -1;
});
var i = function(a) {
return e === a.mensa && f == a.week;
};
for (e in h) for (f in h[e]) g = a.filter(i).length, h[e][f].loaded = g > 0;
return t("mensa"), A(), this;
}, x = function(b, d) {
var f = conf.getSavedURLs(), j = "", k = new Date, l = k.getWeek(), d = d || e.getWeek(), m = "";
b && i.push(b);
for (var n = 0; n < f.length; n++) j = f[n], h[j] = h[j] || {}, !h[j][d] && typeof g[j] == "undefined" && (d === l || d === l + 1) && (c = !1, g[j] = !0, typeof debug != "undefined" && debug ? m = urls.mock[j].replace(/{{week}}/, d) : m = urls.mensenWeek[j].replace(/{{week}}/, d), xhr.get(m, function(b, c) {
var d = "", e = a.length, f = 0;
y(b, c.mensa, c.week), f = a.length, e < f && (h[c.mensa][c.week] = !0), delete g[c.mensa], z();
}, function(a, b) {
console.error("xhr error"), delete g[b.mensa], z();
}, {
mensa: j,
week: d
}));
z();
}, y = function(b, c, d) {
var e, f, g, h, i, j, k, l = [], m = [], n, o, q = document.createElement("div");
q.innerHTML = b.replace(/src="(.)*?"/g, "").replace(/<script(.|\s)*?\/script>/g, "");
try {
f = q.getElementsByTagName("table")[0].getElementsByTagName("tr");
} catch (r) {
return;
}
var s = f[0].getElementsByTagName("th")[0].innerHTML.split("<br>")[1], t = s.split("-")[0].trim(), u = t.split("."), v = new Date(u[2], u[1] - 1, u[0]);
for (var w = 1; w < f.length; w++) {
try {
e = f[w].getElementsByTagName("td"), ths = f[w].getElementsByTagName("th");
} catch (r) {
console.log(r);
continue;
}
h = ths[0].innerText.trim(), h = h.replace(/_+$/, "");
for (var x = 0; x <= 4; x++) {
try {
p = e[x].getElementsByTagName("p");
} catch (r) {
console.log(r);
continue;
}
for (var y = 0; y < p.length; y++) {
if (p[y].getElementsByClassName) priceEl = p[y].getElementsByClassName("price")[0]; else {
var z = p[y].getElementsByTagName("*"), A = z.length;
for (var B = 0; B < A; B++) if (z[B].className === "price") {
priceEl = z[B];
break;
}
}
priceEl ? (price = priceEl.innerHTML.replace("\u20ac", "").replace(" ", "").split("/"), p[y].removeChild(priceEl)) : (price = p[y].innerText.match(/[0-9]+,[0-9][0-9]/g) || [ "0", "0" ], price = price.length === 2 ? price : [ "0", "0" ], p[y].innerHTML = p[y].innerHTML.replace(/[0-9]+,[0-9][0-9]/g, "")), studPrice = price[0].replace(/[^0-9,]/g, ""), normalPrice = price[1].replace(/[^0-9,]/g, ""), l = [], tempObj = {}, n = p[y].getElementsByTagName("img");
for (B = 0; B < n.length; B++) tempObj[n[B].title] = n[B].title;
for (key in tempObj) l.push({
name: key
});
m = [], tempObj = {}, o = p[y].getElementsByTagName("span");
for (B = 0; B < o.length; B++) o[B].className === "tooltip" && (tempObj[o[B].title] = o[B].title);
for (key in tempObj) m.push({
name: key
});
g = p[y].innerText, g = g.replace(/&nbsp;/g, "").trim(), g = g.replace(/\(([0-9.]+,?[\s]*)*\)/g, ""), i = new Date(v.valueOf() + x * 24 * 60 * 60 * 1e3), j = i.getFullYear() + "-" + (i.getMonth() + 1) + "-" + i.getDate(), g !== "" && a.push({
mensa: c,
week: d,
name: h,
dish: g,
studPrice: studPrice,
normalPrice: normalPrice,
date: j,
properties: l,
additives: m
});
}
}
}
}, z = function() {
var a;
if (isEmpty(g)) {
while (i.length > 0) a = i.pop(), a(b);
return A(), !0;
}
return !1;
}, A = function() {
data.save("menu", JSON.stringify(a)), data.save("loadedMensen", JSON.stringify(h));
}, B = function() {
try {
a = JSON.parse(data.get("menu")) || [];
} catch (b) {
a = [];
}
try {
h = JSON.parse(data.get("loadedMensen")) || {};
} catch (b) {
h = {};
}
}, C = function() {
data.remove("menu"), data.remove("loadedMensen");
}, D = function() {
var b = (new Date).getWeek(), c = "";
a = a.filter(function(a) {
return b === a.week || b + 1 === a.week;
}), A();
}, E = function(b) {
x(function() {
var c, d = {}, e = [], f = a.length;
while (f--) d[a[f].name] = !0;
for (c in d) d.hasOwnProperty(c) && e.push(c);
b(e);
});
}, F = function(b) {
x(function() {
var c, d = {}, e = [], f = a.length;
while (f--) d[a[f].name] = !0;
for (c in d) d.hasOwnProperty(c) && e.push({
content: c,
name: c,
filtered: typeof m.name != "undefined" && n.name.indexOf(c) !== -1
});
b(e);
});
}, G = function(a) {
var b = conf.getMensaInfo(), c = b.length, d = 0, e = [];
for (d = 0; d < c; d++) b[d].active && (b[d].filtered = typeof m.mensa != "undefined" && n.mensa.indexOf(b[d].name) !== -1, b[d].content = b[d].name, e.push(b[d]));
a(e);
}, H = function(a) {
var b = J(!0), c = b.length;
while (c--) b[c] = {
filtered: typeof m.date != "undefined" && n.date.indexOf(b[c]) !== -1,
name: b[c],
content: dateToString(b[c])
};
a(b);
}, I = function(a, b) {
switch (a) {
case "date":
H(b);
break;
case "mensa":
G(b);
break;
case "name":
F(b);
}
return this;
}, J = function(a) {
var b = a ? 12 : 5, c = new Date, e = c.getDate() - c.getDay();
d = new Date(c.setDate(e)), dates = [];
for (var f = 0; f < b; f++) d = new Date(d.valueOf() + 864e5), f !== 5 && f !== 6 && dates.push(P(d));
return dates;
}, K = function(a, b) {
b = typeof b == "undefined" ? !0 : b, O(e, b, a);
}, L = function(a, b) {
e = typeof debug != "undefined" && debug ? new Date(2012, 0, 24) : new Date, b = typeof b == "undefined" ? !0 : b, e.getDay() === 6 ? e.setDate(e.getDate() + 2) : e.getDay() === 0 && e.setDate(e.getDate() + 1), O(e, b, a);
}, M = function(a, b) {
var b = typeof b == "undefined" ? !0 : b, c = e.getDay();
return c === 5 ? e.setDate(e.getDate() + 3) : e.setDate(e.getDate() + 1), O(e, b, a), this;
}, N = function(a, b) {
var b = typeof b == "undefined" ? !0 : b, c = e.getDay();
c === 1 ? e.setDate(e.getDate() - 3) : e.setDate(e.getDate() - 1), O(e, b, a);
}, O = function(a, b, c) {
s("date", P(a)), b ? v(function(b) {
c(b, P(a), a);
}) : r(function(b) {
c(b, P(a), a);
});
}, P = function(a) {
return a = new Date(a.valueOf()), a.getFullYear() + "-" + (a.getMonth() + 1) + "-" + a.getDate();
}, Q = function(a) {
return a = a.split("-"), new Date(a[0], a[1] - 1, a[2]);
};
return B(), o(), D(), {
clearCache: C,
cleanData: w,
getInfo: I,
getTypeInfo: F,
getMensaInfo: G,
getDateInfo: H,
getTypes: E,
getAvailableDates: J,
setFilter: s,
unsetFilter: t,
unsetFilters: u,
setMensaFilter: function(a) {
s("mensa", a);
},
unsetMensaFilter: function() {
t("mensa");
},
setNameFilter: function(a) {
s("name", a);
},
unsetNameFilter: function() {
t("name");
},
setDateFilter: function(a) {
s("date", a);
},
unsetDateFilter: function() {
t("date");
},
setPersistentFilters: k,
getPersistentFilters: l,
getWeekMenu: x,
getSortedSegmented: v,
filter: r,
thisDay: K,
nextDay: M,
prevDay: N,
today: L
};
}();

// js/filterList.js

enyo.kind({
name: "filterList",
kind: enyo.VFlexBox,
type: "mensa",
components: [ {
kind: "SpinnerLarge",
showing: !0
}, {
kind: "Scroller",
flex: 1,
components: [ {
kind: "Repeater",
onSetupRow: "listSetupRow"
} ]
} ],
data: [],
create: function() {
this.inherited(arguments), this.load();
},
load: function() {
var a = this;
this.$.spinnerLarge.show(), storage.getInfo(this.type, function(b) {
a.$.spinnerLarge.hide(), a.data = b, a.data.unshift({
content: "Alle",
value: "all",
filtered: b.filter(function(a) {
return a.filtered;
}).length === 0
}), a.$.repeater.render();
});
},
listSetupRow: function(a, b) {
var c = this.data[b];
if (c) return {
kind: "Item",
className: c.filtered ? "enyo-held" : "dummy",
layoutKind: "HFlexLayout",
onclick: "itemClick",
components: [ {
content: c.content,
value: c.name,
flex: 1
} ]
};
},
itemClick: function(a) {
var b = this.owner.$.menuList, c = a.parent.children.length, d = a.children[0].content === "Alle", e = a.parent, f;
this.filterList = [], a.hasClass("enyo-held") ? a.removeClass("enyo-held") : (a.parent.children[0].removeClass("enyo-held"), a.addClass("enyo-held"));
for (var g = 1; g < c; g++) f = e.children[g], f.hasClass("enyo-held") && (d ? f.removeClass("enyo-held") : this.filterList.push(f.children[0].value));
this.filterList.length === 0 && (a.parent.children[0].addClass("enyo-held"), d = !0), d ? storage.unsetFilter(this.type) : storage.setFilter(this.type, this.filterList), storage.getSortedSegmented(function(a) {
b.data = a, b.render();
});
}
});

// js/menuList.js

enyo.kind({
name: "menuList",
kind: enyo.VFlexBox,
components: [ {
kind: "SpinnerLarge",
showing: !0
}, {
kind: "Scroller",
flex: 1,
components: [ {
kind: "Repeater",
onSetupRow: "listSetupRow"
} ]
} ],
data: [],
create: function() {
this.inherited(arguments), this.load();
},
displayStudentPrices: conf.displayStudentPrices(),
load: function() {
var a = this;
this.$.spinnerLarge.show(), storage.getSortedSegmented(function(b) {
a.$.spinnerLarge.hide(), a.data = b, a.$.repeater.render();
});
},
listSetupRow: function(a, b) {
var c = this.data[b];
if (c) {
if (c.type === "header") return {
kind: "Divider",
caption: c.headerType === "date" ? dateToString(c.header) : c.header
};
if (c.dish) return {
kind: "Item",
className: "enyo-item" + (c.first ? " enyo-first" : "") + (c.last ? " enyo-last" : ""),
components: [ {
content: c.dish
}, {
layoutKind: "HFlexLayout",
components: [ {
content: c.name,
flex: 1
}, {
content: (this.displayStudentPrices ? c.studPrice : c.normalPrice) + "\u20ac"
} ]
} ]
};
}
}
});

// js/main.js

enyo.kind({
name: "main",
kind: enyo.VFlexBox,
components: [ {
kind: "AppMenu",
components: [ {
caption: "Konfigurieren",
onclick: "conf",
onclick: "openConfig"
}, {
caption: "\u00dcber diese App",
onclick: "about",
onclick: "openAbout"
}, {
caption: "Zur\u00fccksetzen",
onclick: "reset",
onclick: "reset"
} ]
}, {
kind: "ModalDialog",
name: "about",
caption: info.appName,
components: [ {
content: info.appDesc
}, {
kind: "Button",
className: "enyo-button-affirmative",
caption: $L("Ok"),
onclick: "closePopup"
}, {
kind: "Button",
caption: $L("Zur Projektseite"),
onclick: "moreInfo"
}, {
kind: "Button",
caption: $L("Email schreiben"),
onclick: "email"
} ]
}, {
name: "openEmail",
kind: "PalmService",
service: "palm://com.palm.applicationManager",
method: "open",
onSuccess: "openEmailSuccess",
onFailure: "openEmailFailure",
subscribe: !0
}, {
name: "slidingPane",
kind: "SlidingPane",
flex: 1,
components: [ {
name: "left",
width: "160px",
kind: "SlidingView",
components: [ {
kind: "Header",
content: "Tage"
}, {
kind: "Scroller",
flex: 1,
components: [ {
name: "dateList",
flex: 1,
type: "date",
peekWidth: 100,
kind: "filterList"
} ]
}, {
kind: "Toolbar",
components: [ {
kind: "GrabButton"
} ]
} ]
}, {
name: "mensalistpanel",
width: "160px",
kind: "SlidingView",
peekWidth: 50,
components: [ {
kind: "Header",
content: "Mensen"
}, {
kind: "Scroller",
flex: 1,
components: [ {
name: "mensaList",
flex: 1,
type: "mensa",
peekWidth: 100,
kind: "filterList"
} ]
}, {
kind: "Toolbar",
components: [ {
kind: "GrabButton"
} ]
} ]
}, {
name: "middle2",
width: "160px",
kind: "SlidingView",
peekWidth: 100,
components: [ {
kind: "Header",
content: "Gerichte"
}, {
kind: "Scroller",
flex: 1,
components: [ {
name: "nameList",
flex: 1,
type: "name",
peekWidth: 100,
kind: "filterList"
} ]
}, {
kind: "Toolbar",
components: [ {
kind: "GrabButton"
} ]
} ]
}, {
name: "right",
kind: "SlidingView",
flex: 1,
peekWidth: 150,
components: [ {
kind: "Header",
content: "Speisekarte"
}, {
kind: "Scroller",
flex: 1,
components: [ {
name: "menuList",
flex: 1,
peekWidth: 100,
kind: "menuList"
} ]
}, {
kind: "Toolbar",
components: [ {
kind: "GrabButton"
}, {
content: "Mensa Hamburg",
onclick: "openAbout"
}, {
icon: "images/Gear.png",
onclick: "closePopup",
onclick: "openConfig"
} ]
} ]
}, {
kind: "ModalDialog",
name: "conf",
caption: "Zu ladene Mensen",
components: [ {
kind: "Group",
components: [ {
kind: "Picker",
value: conf.displayStudentPrices(),
items: [ {
caption: "Studentenpreise anzeigen",
value: !0
}, {
caption: "Nicht-Studentenpreise anzeigen",
value: !1
} ],
onChange: "changeStudentPrice"
}, {
kind: "Scroller",
height: "230px",
components: [ {
kind: "Repeater",
onSetupRow: "listSetupRow"
} ]
} ]
}, {
kind: "Button",
className: "enyo-button-affirmative",
caption: $L("Speichern"),
onclick: "saveConf"
}, {
kind: "Button",
className: "enyo-button-negative",
caption: $L("App zur\u00fccksetzen"),
onclick: "reset"
} ]
} ]
} ],
openConfig: function(a, b) {
this.$.conf.openAtCenter();
},
openAbout: function(a, b) {
this.$.about.openAtCenter();
},
data: [],
listSetupRow: function(a, b) {
var c = this.data[b], d = conf.getSavedURLs(), e = conf.isConfigured();
if (c) return {
kind: "RowItem",
layoutKind: "HFlexLayout",
components: [ {
content: c,
flex: 1
}, {
kind: "ToggleButton",
state: e && d.indexOf(c) != -1
} ]
};
},
moreInfo: function(a, b) {
location.href = info.appURL, this.closePopup(a, b);
},
email: function(a, b) {
location.href = "mailto: " + info.appEmail, this.closePopup(a, b);
},
reset: function(a, b) {
data.clear(), location.reload();
},
closePopup: function(a, b) {
a.parent.parent.parent.close();
},
changeStudentPrice: function(a, b) {
conf.setStudentPrices(b), this.$.menuList.displayStudentPrices = b;
},
saveConf: function(a, b) {
var c = [], d, e = a.parent.children[0].children[1].children[1].children[0].children[0].children;
for (d = 0; d < e.length; d++) e[d].children[1].state && c.push(e[d].children[0].content);
conf.setURLs(c), storage.cleanData(), this.owner.$.main.$.mensaList.load(), this.owner.$.main.$.nameList.load(), this.owner.$.main.$.menuList.load(), this.closePopup(a, b);
},
create: function() {
this.inherited(arguments), this.data = conf.getURLs();
var a = this.$.conf;
window.addEventListener("load", function() {
conf.isConfigured() || a.openAtCenter();
}, !1);
}
}), window.onload = function() {
(new main).renderInto(document.body);
};
